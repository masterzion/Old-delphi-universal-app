Demo project.
=============

Created by Kim Madsen (kbm@components4developers.com)
-----------------------------------------------------

Demo's many of the features available in kbmMemTable v. 4.xx,
eg. sorting, indexes, searching, save/load operation,
compression of save/load and blobs, filtering, transactions,
versioning, snapshots etc.
